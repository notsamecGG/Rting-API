This is chrome unpacked extension

On every page you'll get iframe popup accessing https API, ..